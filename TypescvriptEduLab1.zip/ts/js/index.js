"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// 1) Variáveis simples + inferência
// O TypeScript consegue inferir o tipo das variáveis com base no valor atribuído.
// Aqui, 'nomeAluno' é uma string, 'nota1' e 'nota2' são números, e 'aprovado' é um booleano.
var nomeAluno = 'Ana'; // nomeAluno é uma string
var nota1 = 8.5; // nota1 é um número
var nota2 = 7; // nota2 é um número
var aprovado = true; // aprovado é um booleano
console.log('1) Variáveis:', { nomeAluno: nomeAluno, nota1: nota1, nota2: nota2, aprovado: aprovado });
// 2) Tipos explícitos + função tipada (média)
// Aqui definimos uma função 'media' que recebe dois números e retorna a média entre eles.
// A função também tem seu tipo de retorno explícito como 'number', garantindo que sempre retornará um número.
function media(a, b) {
    return Number(((a + b) / 2).toFixed(2)); // Retorna a média arredondada para 2 casas decimais.
}
var mediaAna = media(nota1, nota2); // Calcula a média de 'nota1' e 'nota2'
console.log('2) Média de Ana:', mediaAna);
// 3) Array tipado + map/filter
// Definimos um array tipado de números ('notas') e aplicamos métodos como 'filter' e 'map'.
// 'filter' retorna apenas as notas maiores ou iguais a 8.
// 'map' ajusta todas as notas, aumentando 0.5 (mas nunca acima de 10).
var notas = [6, 7.5, 8, 9.2, 10]; // Array de notas, todas do tipo número.
var acimaDe8 = notas.filter(function (n) { return n >= 8; }); // Filtra notas maiores ou iguais a 8.
var mediasAjustadas = notas.map(function (n) { return Math.min(n + 0.5, 10); }); // Ajusta as notas, aumentando 0.5, mas limita a 10.
console.log('3) Arrays:', { acimaDe8: acimaDe8, mediasAjustadas: mediasAjustadas });
// 4) Tupla (nome, média) + ordenação
// Uma tupla é como um array, mas com tipos definidos e quantidade fixa de elementos.
// Aqui, estamos criando uma tupla para registrar o nome de um aluno e sua média.
var registro = ['Edu', media(9, 8.5)]; // Tupla contendo nome (string) e média (número)
console.log('4) Tupla (nome, média):', registro);
var alunos = [
    { id: 'a1', nome: 'Ana', notas: [8, 7.5, 9] },
    { id: 'a2', nome: 'Bia', notas: [6, 6.5, 7] },
    { id: 'a3', nome: 'Cris', notas: [9.5, 8.5, 10] },
];
function mediaAluno(a) {
    var soma = a.notas.reduce(function (acc, n) { return acc + n; }, 0); // Soma todas as notas
    return Number((soma / a.notas.length).toFixed(2)); // Calcula a média e arredonda para 2 casas decimais
}
console.log('5) Médias:', alunos.map(function (a) { return ({ nome: a.nome, media: mediaAluno(a) }); }));
function formatarId(id) {
    return typeof id === 'number' ? id.toString().padStart(3, '0') : id.toUpperCase(); // Formatação baseada no tipo
}
console.log('6) União:', formatarId(7), formatarId('a3'));
// 7) Enum de status + classificação por média
// Usamos um 'enum' para representar os possíveis status de um aluno (aprovado, recuperação ou reprovado).
// A função 'statusPorMedia' usa a média do aluno para determinar seu status.
var StatusAluno;
(function (StatusAluno) {
    StatusAluno["Aprovado"] = "APROVADO";
    StatusAluno["Recuperacao"] = "RECUPERA\u00C7\u00C3O";
    StatusAluno["Reprovado"] = "REPROVADO";
})(StatusAluno || (StatusAluno = {})); // Define o enum
function statusPorMedia(m) {
    if (m >= 7)
        return StatusAluno.Aprovado; // Aprovado se a média for maior ou igual a 7
    if (m >= 5)
        return StatusAluno.Recuperacao; // Recuperação se a média for entre 5 e 7
    return StatusAluno.Reprovado; // Reprovado se a média for abaixo de 5
}
console.log('7) Status:', alunos.map(function (a) { return ({ nome: a.nome, status: statusPorMedia(mediaAluno(a)) }); }));
// 8) Map<string, number> (nome → média)
// Aqui, usamos um 'Map' para associar o nome de cada aluno à sua média.
// O 'Map' permite armazenar pares chave-valor, e a chave é o nome do aluno enquanto o valor é a média calculada.
var mediasPorNome = new Map(); // Cria um novo mapa onde a chave é o nome (string) e o valor é a média (número)
for (var _i = 0, alunos_1 = alunos; _i < alunos_1.length; _i++) {
    var a = alunos_1[_i];
    mediasPorNome.set(a.nome, mediaAluno(a));
} // Adiciona cada aluno ao mapa
console.log('8) Map (nome→média):', Array.from(mediasPorNome.entries())); // Exibe o mapa como um array de pares chave-valor
